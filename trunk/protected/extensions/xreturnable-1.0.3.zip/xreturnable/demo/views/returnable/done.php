<?php echo CHtml::link('Returnable Start',array('index')) ?>
<h1>Aktion ausgeführt!</h1>
<p>Es wurde keine Rückkehr-URL vorgefunden. Daraum wird diese Standardseite angezeigt</p>
